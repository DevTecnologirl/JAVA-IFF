package lista04Q3;

public class Circulo 
{
	//atributo
		private float raio;
		
		public void setRaio (float r)
		{
			raio=r;
		}
		public int getRaio ()
		{
			return raio;
		}
		//opera��es
		public double calcularArea()
		{	return Math.PI*Math.pow(raio,2);	}
		
		public double calcularPerimetro()
		{	return 2*Math.PI*raio;	}
		
		public float calcularDiametro()
		{	return 2*raio;	}

}
