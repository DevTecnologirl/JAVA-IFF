package src.lista04Q5;

import src.lista04Q1.String;

public class testeNumero
{
	public static void main(String[] args)
	{
	//3 passos para teste: 
	//1- criar um objeto da classe: retangulo (instanciar a classe)
	//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
	Numero objNumero = new Numero();
	
	
	//2- preencher valores para os atributos do objeto.(atribui��o ou leitura) 
	objNumero.setValor(15);
	
	
	
	//3- chamar as opera��es do objeto e mostrar os resultados na tela
	System.out.println("Raiz Quadrada do Numero = "+objNumero.calcularRaiz2());
	System.out.println("Raiz C�bica do Numero = "+objNumero.calcularRaiz3());
	System.out.println("Potencia do Numero = "+objNumero.calcularPotencia());
	System.out.println("N� Primo do Numero = "+objNumero.verificarPrimo());
	objNumero.verificarParouImpar());
	}
}
