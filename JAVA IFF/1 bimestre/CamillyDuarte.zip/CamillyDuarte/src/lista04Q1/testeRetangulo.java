package src.lista04Q1;

public class testeRetangulo 
{

	public static void main(String[] args)
	{
		//3 passos para teste: 
		//1- criar um objeto da classe: retangulo (instanciar a classe)
		//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
		Retangulo objRetangulo = new Retangulo();
		
		
		//2- preencher valores para os atributos do objeto.(atribui��o ou leitura) 
		objRetangulo.setBase(5);
		objRetangulo.setAltura(8);
		
		
		//3- chamar as opera��es do objeto e mostrar os resultados na tela
		
		System.out.println("�rea do ret�ngulo = "+objRetangulo.calcularArea());
		System.out.println("Perimetro do retangulo = "+objRetangulo.calcularPerimetro());
		System.out.println("Diagonal do retangulo = "+objRetangulo.calcularDiagonal());
	}

}
//OBS: MEUS TESTES N�O EST�O RODANDO PELOS PROBLEMAS QUE INFORMEI NO CHAT DO WPP