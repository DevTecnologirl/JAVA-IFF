package src.lista04Q8;

import src.lista04Q1.String;

public class testeData
{
	public static void main(String[] args) 
{
	//3 passos para teste: 
	//1- criar um objeto da classe: retangulo (instanciar a classe)
	//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
	Data objData = new Data();
	
	
	//2- preencher valores para os atributos do objeto.(atribui��o ou leitura) 
	objData.setDia(8);
	objData.setMes(10);
	objData.setAno(2020);
	
	
	//3- chamar as opera��es do objeto e mostrar os resultados na tela
	objData.verificarDataValida();
	System.out.println("Ano bissexto = "+objData.verificarAnoBissexto());
	System.out.println("Data imprimida = "+objData.imprimirData());
}
}
