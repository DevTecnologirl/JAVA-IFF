package lista04Q7;

public class Hora
{
	//atributos
		private int hora;
		private int minuto;
		private int segundo;
		private String formato;
				
		
		
		public void setHora (int h)
		{   hora = h; }
		
		public int getHora()
		{return hora;}
		
		public void setMinuto (int m)
		{   minuto = m; }
		
		public int getMinuto()
		{return minuto;}
		
		public void setSegundo (int s)
		{   segundo=s; }
		
		public int getSegundo()
		{return segundo;}
		
		public void setFormato (String f)
		{   formato=f; }
		
		public float getFormato()
		{return formato;}
		
		
		
		//opera��es
		public void converterHM()
		{	minuto = minuto + (hora*60);
			hora = 0;
		}
				
		public void converterHS()
		{	segundo = segundo+(hora*3600);
			hora = 0;
		}
			
		public void converterMH()
		{	hora = hora + (minuto/60);
			minuto = minuto%60;
		}
			
		public void converterMS()
		{	segundo = segundo + (minuto*60);
			minuto = 0;
		}
			
		public void converterSH()
		{	hora = hora + (segundo/3600);
			segundo = segundo%3600;
		}
			
		public void converterSM()
		{	minuto = minuto + (segundo/60);
			segundo = segundo%60;
		}

		public void verificarHoraValida()
		{	int dia=0;
			if(segundo>59)
			{	converterSM();	}
			if(minuto>59)
			{	converterMH();}				
			if(hora>23)
			{	dia = dia + (hora/24);
				hora = hora -(dia*24);
			}
			imprimirHora(dia);
		}
		
		public void imprimirHora(int dia)
		{	String horacompleta,tipo,h,m,s;
			
			h=String.valueOf(hora);
			m=String.valueOf(minuto);
			s=String.valueOf(segundo);
			if(hora<10)
			{	h="0"+h;	}
			if(minuto<10)
			{	m="0"+m;	}
			if(segundo<10)
			{	s="0"+s;	}
		
			if (formato.equalsIgnoreCase("24h"))
			{   horacompleta = dia+" dia(s) - "+h+":"+m+":"+s;
				System.out.println(horacompleta);
			}	
			else
			{  if(hora>12)
			   {	hora=hora-12;
			   		h=String.valueOf(hora);
			   		tipo="pm"; 		
			   }
			   else tipo="am";
			   horacompleta = dia+" dia(s) - "+h+":"+m+":"+s+" "+tipo;
			   System.out.println(horacompleta);
			}
		}
}
