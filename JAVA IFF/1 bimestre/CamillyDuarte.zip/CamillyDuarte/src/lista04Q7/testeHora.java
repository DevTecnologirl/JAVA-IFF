package src.lista04Q7;

import src.lista04Q1.String;

public class testeHora 
{
	public static void main(String[] args) 
	{
	//3 passos para teste: 
	//1- criar um objeto da classe: retangulo (instanciar a classe)
	//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
	Hora objHora = new Hora();
	
	
	//2- preencher valores para os atributos do objeto.(atribui��o ou leitura) 
	objHora.setHora(4);
	objHora.setMinuto(480);
	objHora.setSegundo(14000);
	
	
	
	//3- chamar as opera��es do objeto e mostrar os resultados na tela
	objHora.converterHM();
	objHora.converterHS();
	objHora.converterMH();
	objHora.converterMS();
	objHora.converterSH();
	objHora.converterSM();
	objHora.imprimirHora();
	objHora.verificarHoraValida();
	}

}

