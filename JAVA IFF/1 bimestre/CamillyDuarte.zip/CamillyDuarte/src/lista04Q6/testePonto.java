package src.lista04Q6;

import src.lista04Q1.String;

public class testePonto
{
	public static void main(String[] args) 
	{
	//3 passos para teste: 
	//1- criar um objeto da classe: retangulo (instanciar a classe)
	//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
	Ponto objPonto = new Ponto();
	
	
	//2- preencher valores para os atributos do objeto.(atribui��o ou leitura) 
	objPonto.setX(9);
	objPonto.setY(18);
	
	
	
	//3- chamar as opera��es do objeto e mostrar os resultados na tela
	objPonto.moverH();
	objPonto.moverV();
	objPonto.moverHV();
	objPonto.informarQuadrante();
	System.out.println("Distancia da Origem = "+objQPonto.calcularDistanciaOrigem();
	objPonto.imprimirPonto();
	}

}
