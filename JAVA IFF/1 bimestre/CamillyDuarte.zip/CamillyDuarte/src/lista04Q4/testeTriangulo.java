package src.lista04Q4;

import src.lista04Q1.String;
import src.lista04Q2.Quadrado;

public class testeTriangulo
{
	public static void main(String[] args)
	{
	//3 passos para teste: 
	//1- criar um objeto da classe: retangulo (instanciar a classe)
	//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
	Triangulo objTriangulo = new Triangulo();
	
	
	//2- preencher valores para os atributos do objeto.(atribui��o ou leitura) 
	objTriangulo.setAltura(4);
	objTriangulo.setTipo(3);
	objTriangulo.setBase(8);
	
	
	//3- chamar as opera��es do objeto e mostrar os resultados na tela
	System.out.println("Area do Triangulo = "+objTriangulo.calcularArea());
	System.out.println("Perimetro do Triangulo = "+objTriangulo.calcularPerimetro());
	System.out.println("Tipo do triangulo: "+objTriangulo.setTipo());
	}
}

