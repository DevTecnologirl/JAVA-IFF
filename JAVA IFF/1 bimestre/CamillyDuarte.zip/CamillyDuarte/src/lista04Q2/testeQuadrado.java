package src.lista04Q2;

import src.lista04Q1.Retangulo;
import src.lista04Q1.String;

public class testeQuadrado 
{
	public static void main(String[] args)
	{
	//3 passos para teste: 
			//1- criar um objeto da classe: retangulo (instanciar a classe)
			//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
			Quadrado objQuadrado = new Quadrado();
			
			
			//2- preencher valores para os atributos do objeto.(atribui��o ou leitura) 
			objQuadrado.setLado(2);
			
			
			
			//3- chamar as opera��es do objeto e mostrar os resultados na tela
			System.out.println("Area do quadrado = "+objQuadrado.calcularArea());
			System.out.println("Perimetro do quadrado = "+objQuadrado.calcularPerimetro());
			System.out.println("Diagonal do quadrado = "+objQuadrado.calcularDiagonal());

	}
}