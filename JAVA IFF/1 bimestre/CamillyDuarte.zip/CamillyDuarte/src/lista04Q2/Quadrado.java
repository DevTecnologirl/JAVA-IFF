package lista04Q2;

public class Quadrado {
	//atributo
		private float lado;
		
		public void setLado (float l)
		{
			lado = l;
		}
		public int getLado()
		{
			return lado;
		}
		
		//opera��es
		public double calcularArea()
		{	return Math.pow(lado,2);	}
		
		public float calcularPerimetro()
		{	return 4*lado;	}
		
		public double calcularDiagonal()
		{	return Math.sqrt(2*Math.pow(lado,2));	}

}
