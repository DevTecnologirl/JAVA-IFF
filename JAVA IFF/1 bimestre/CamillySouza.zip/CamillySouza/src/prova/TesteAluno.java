package prova;

public class TesteAluno
{
	public static void main(String[] args)
	{
		//1º passo: criar um objeto da classe Hora (instanciar a classe Hora)
		//Sintaxe: NomeClasse nomeObjeto = new NomeClasse();
		Aluno objAluno = new Aluno();
		
		//2º passo: preencher valores para os atributos do objeto (atribuição ou leitura)
		objAluno.setMatricula(Integer.parseInt(JOptionPane.showInputDialog("Informe sua matrícula: ")));
		objAluno.setNome(JOptionPane.showInputDialog("Informe seu nome: "));
		objAluno.setDisciplina(JOptionPane.showInputDialog("Informe a disciplina: "));
		objAluno.setNotaP1(Integer.parseInt(JOptionPane.showInputDialog("Informe sua nota P1: ")));
		objAluno.setNotaP2(Integer.parseInt(JOptionPane.showInputDialog("Informe sua nota P2: ")));
		
		//3º passo: chamar as operações do objeto e mostrar os resultados na tela	
		objAluno.getNome();
		objAluno.getMatricula();
		objAluno.getDisciplina();
		objAluno.getNotaP1();
		objAluno.getNotaP2();
	}
}
}
