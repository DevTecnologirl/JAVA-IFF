package prova;

import javax.swing.JOptionPane;

public class Aluno
{
//ATRIBUTOS
	//a)
	private int matricula;
	private String nome;
	private String disciplina;
	private float notaP1;
	private float notaP2;
	
	

//METODO
	public void setMatricula (int m)
	{
		matricula=m;
	}
	public int getMatricula()
	{
		return matricula;
	}
	
	public void setNome (String n)
	{
		nome=n;
	}
	public String getNome()
	{
		return nome;
	}
	
	public void setDisciplina(String d)
	{
		disciplina=d;
	}
	public String getDisciplina()
	{
		return disciplina;
	}
	
	public void setNotaP1(float n1)
	{
		notaP1=n1;
	}
	public float getNotaP1()
	{
		return notaP1;
	}
	
	public void setNotaP2 (float n2)
	{
		notaP2=n2;
	}
	public float getNotaP2()
	{
		return notaP2;
	}
	
	
//OPERAÇÃO
	//b)
	public void inicializar()
	{
		JOptionPane.showInputDialog(null,nome);
		JOptionPane.showInputDialog(null,disciplina);
		JOptionPane.showInputDialog(null,notaP1);
		JOptionPane.showInputDialog(null,notaP2);
		
	}
	//c)
	
	public float calcularMedia()
	{
		 return (notaP1+notaP2)/2;
	}
	public void imprimir()
	{
		JOptionPane.showMessageDialog(null,calcularMedia());
	}
	
	//d)
	public void imprimirBoletim()
	{
		JOptionPane.showMessageDialog(null,nome);
		JOptionPane.showMessageDialog(null,disciplina);
		JOptionPane.showMessageDialog(null,notaP1);
		JOptionPane.showMessageDialog(null,notaP2);
	
		JOptionPane.showMessageDialog(null,calcularMedia());
	}
	
}
