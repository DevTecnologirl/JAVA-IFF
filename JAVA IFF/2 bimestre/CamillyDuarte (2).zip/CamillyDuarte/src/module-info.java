module P2 
{
	requires java.desktop;
	//atributos
	
	//atributos de referencia
	
	//metodo SET E GET
	
	//metodo construtor
	
	//operações
	
	import javax.swing.JOptionPane;
}