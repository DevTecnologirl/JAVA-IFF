package Lista6Q3;
import javax.swing.JOptionPane;
public class testeCirculo 
{
	public static void main(String[] args) 
	{
		//3 passos para teste: 
		//1- criar um objeto da classe: retangulo (instanciar a classe)
		//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
		Circulo objCirculo = new Circulo();
		
		
		//2- chamar as operações do objeto e mostrar os resultados na tela
		JOptionPane.showMessageDialog(null,"Area do circulo = "+objCirculo.calcularArea());
		JOptionPane.showMessageDialog(null,"Perimetro do circulo = "+objCirculo.calcularPerimetro());
		JOptionPane.showMessageDialog(null,"Diametro do circulo = "+objCirculo.calcularDiametro());
	}

}
