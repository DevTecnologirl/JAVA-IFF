package Lista6Q3;
import javax.swing.JOptionPane;
public class Circulo
{
	//atributo
			private float raio;
	
	
	//metodo
			public void setRaio(float r)
			{
				raio=r;
			}
			public float getRaio()
			{
				return raio;
	
		    }
			
	//metodod construtor
			public Circulo()
			{
			raio = Float.parseFloat(JOptionPane.showInputDialog("Informe o raio: ")); 
			}
			
	//operações
			public double calcularArea()
			{	return Math.PI*Math.pow(raio,2);	}
			
			public double calcularPerimetro()
			{	return 2*Math.PI*raio;	}
			
			public float calcularDiametro()
			{	return 2*raio;	}

}
