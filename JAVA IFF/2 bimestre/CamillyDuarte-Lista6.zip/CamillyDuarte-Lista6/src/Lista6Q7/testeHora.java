package Lista6Q7;
import javax.swing.JOptionPane;
public class testeHora 
{
	public static void main(String[] args)
	{
		//1º passo: criar um objeto da classe Hora (instanciar a classe Hora)
		//Sintaxe: NomeClasse nomeObjeto = new NomeClasse();
		Hora objHora = new Hora();
		
		//2º passo: chamar as operações do objeto e mostrar os resultados na tela	
		objHora.verificarHoraValida();
	}

}
