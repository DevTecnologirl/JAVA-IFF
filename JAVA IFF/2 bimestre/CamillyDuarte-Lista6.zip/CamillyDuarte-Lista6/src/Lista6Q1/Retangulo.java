package Lista6Q1;
import javax.swing.JOptionPane;
public class Retangulo 
{
//atributos
	private float base;
	private float altura;
	
//atributo de classe
	private static int numeroLados = 4;
	
//METODOS: set e get
	public void setBase(float b)
	{
		base=b;
	}
	public float getBase()
	{
		return base;
	}
	
	public void setAltura(float a)
	{
		altura=a;
	}
	public float getAltura()
	{
		return altura;
	}
	//metodo - atributo de classe
	public static void setNumeroLados (int nl)
	{
		numeroLados = nl;
	}
	public static int getNumeroLados()
	{
		return numeroLados;
	}
//metodo construtor 
	public Retangulo()
{
		base = Float.parseFloat(JOptionPane.showInputDialog("Informe o valor da base: "));
		altura = Float.parseFloat(JOptionPane.showInputDialog("Informe o valor da altura: "));
}
//operação
	public float calcularArea()
	{
		return base*altura;
	}
	public float calcularPerimetro()
	{
		return 2*(base+altura);
	}
	public double calcularDiagonal()
	{
		return Math.sqrt(Math.pow(base,2)+Math.pow(altura,2));
	}
	
	
}
