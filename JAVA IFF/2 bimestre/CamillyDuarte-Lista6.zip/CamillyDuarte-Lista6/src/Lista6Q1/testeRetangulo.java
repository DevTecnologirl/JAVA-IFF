package Lista6Q1;
import javax.swing.JOptionPane;
public class testeRetangulo {
	public static void main(String[] args)
	{	
		//1º passo: criar um objeto da classe Retangulo (instanciar a classe Retangulo)
		//Sintaxe: NomeClasse nomeObjeto = new NomeClasse();
		Retangulo objRetangulo = new Retangulo();
		
		//2º passo: chamar as operações do objeto e mostrar os resultados na tela	
		JOptionPane.showMessageDialog(null,"Área do retângulo = "+objRetangulo.calcularArea());
		JOptionPane.showMessageDialog(null,"Perímetro do retângulo = "+objRetangulo.calcularPerimetro());
		JOptionPane.showMessageDialog(null,"Diagonal do retângulo = "+objRetangulo.calcularDiagonal());		
	}
}

