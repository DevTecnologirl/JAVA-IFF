package Lista6Q4;
import javax.swing.JOptionPane;
public class Triangulo 
{
	//atributos
	private float base;
	private float altura;
	private String tipo;
	
	//atributo de classe
	private static int numeroLados = 3;
	
	
	//metodo
	public void setTipo (String t)
	{
		tipo=t;
	}
	public String getTipo ()
	{
		return tipo;
	}
	public void setAltura (float a)
	{
		altura = a;
	}
	public float getAltura ()
	{
		return altura;
	}
	public void setBase (float b)
	{
		base=b;
	}
	public float getBase ()
	{
		return base;
	}
	public static void setNumeroLados(int nl)
	{
		numeroLados = nl;
	}
	public static int getNumeroLados()
	{
		return numeroLados;
	}
	
	//metodo construtor
	public Triangulo()
	{
		base = Float.parseFloat(JOptionPane.showInputDialog("Informe o valor da base: "));
		altura = Float.parseFloat(JOptionPane.showInputDialog("Informe o valor da altura: "));
		tipo =	JOptionPane.showInputDialog("Informe o tipo: ");
	 
	}
	
	//operações
	public float calcularArea()
	{	return (base*altura)/2;		}
	
	public double calcularPerimetro()
	{	if(tipo.equalsIgnoreCase("equilátero"))
		{	return 3*base;	}
		else if(tipo.equalsIgnoreCase("isóseles"))
		{	return (2* Math.sqrt(Math.pow(altura,2)+Math.pow(base/2,2)))+base;	}
		else
		{	float lado1=10,lado2=20;	
			return lado1+lado2+base;	
		}	
	}
}
