package Lista6Q4;
import javax.swing.JOptionPane;
public class testeTriangulo 
{
	public static void main(String[] args)
	{
	 
	//1- criar um objeto da classe: retangulo (instanciar a classe)
	//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
	Triangulo objTriangulo = new Triangulo();
	
	
	//2- chamar as operações do objeto e mostrar os resultados na tela
	JOptionPane.showMessageDialog(null,"Area do Triangulo = "+objTriangulo.calcularArea());
	JOptionPane.showMessageDialog(null,"Perimetro do Triangulo = "+objTriangulo.calcularPerimetro());
	JOptionPane.showMessageDialog(null,"Tipo do triangulo: "+objTriangulo.setTipo());
	}

}
