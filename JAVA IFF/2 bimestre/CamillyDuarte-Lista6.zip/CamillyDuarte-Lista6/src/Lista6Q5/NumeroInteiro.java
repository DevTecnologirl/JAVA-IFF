package Lista6Q5;
import javax.swing.JOptionPane;
public class NumeroInteiro 
{
	//atributo
			private int valor;
			
	//metodo
			public void setValor (int v)
			{
				valor = v;
			}
			public int get()
			{
				return valor;
			}
			
		//metodo construtor
			public NumeroInteiro()
			{
			valor = Integer.parseInt(JOptionPane.showInputDialog("Informe o valor do numero inteiro: "));	
			}
			
			//operações
			public double calcularRaiz2()
			{	return Math.sqrt(valor);	}
			
			public double calcularRaiz3()
			{	return Math.cbrt(valor);	}
			
			public double calcularPotencia(float exp)
			{	return Math.pow(valor,exp);	}
			
			public int calcularFatorial()
			{	int fat=1;
				if(valor>1)
				{	for(int i=1;i<=valor;i++)
					{ fat = fat*i;	}
				}
				return fat;
			}
			
			public void verificarParouImpar()
			{	if(valor%2==0)
				{	System.out.println("O número é par!");		}
				else
				{	System.out.println("O número é ímpar!");	}
			}
			
			public boolean verificarPrimo()
			{	int cont=0;
				for(int i=1;i<=valor;i++)
				{	if(valor%i==0)
					{	cont++;	}
				}
				if(cont==2)
				{	return true;	}
				else
				{	return false;	}
			}

}
