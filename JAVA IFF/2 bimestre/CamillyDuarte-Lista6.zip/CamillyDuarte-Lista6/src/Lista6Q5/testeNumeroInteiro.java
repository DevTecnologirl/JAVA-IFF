package Lista6Q5;
import javax.swing.JOptionPane;
public class testeNumeroInteiro 
 
{
	public static void main(String[] args)
	{
	//3 passos para teste: 
	//1- criar um objeto da classe: retangulo (instanciar a classe)
	//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
	Numero objNumero = new Numero();

	//2- chamar as operações do objeto e mostrar os resultados na tela
	JOptionPane.showMessageDialog(null,"Raiz Quadrada do Numero = "+objNumero.calcularRaiz2());
	JOptionPane.showMessageDialog(null,"Raiz Cúbica do Numero = "+objNumero.calcularRaiz3());
	JOptionPane.showMessageDialog(null,"Potencia do Numero = "+objNumero.calcularPotencia());
	JOptionPane.showMessageDialog(null,"N° Primo do Numero = "+objNumero.verificarPrimo());
	
	}

}
