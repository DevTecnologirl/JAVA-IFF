package Lista6Q2;
import javax.swing.JOptionPane;
public class testeQuadrado 
{
	public static void main(String[] args)
	{
	//3 passos para teste: 
			//1- criar um objeto da classe: retangulo (instanciar a classe)
			//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
			Quadrado objQuadrado = new Quadrado();
			
			//2- chamar as operações do objeto e mostrar os resultados na tela
			JOptionPane.showMessageDialog(null,"Area do quadrado = "+objQuadrado.calcularArea());
			JOptionPane.showMessageDialog(null,"Perimetro do quadrado = "+objQuadrado.calcularPerimetro());
			JOptionPane.showMessageDialog(null,"Diagonal do quadrado = "+objQuadrado.calcularDiagonal());
	}

}
