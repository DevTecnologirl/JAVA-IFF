package Lista6Q2;
import javax.swing.JOptionPane;
public class Quadrado 
{
	//atributo
	private float lado;

	//atributo de classe
	private static int numeroLados = 4;
	
	//metodo
	private void setLado (float l)
	{
		lado=l;
	}
	private float getLado()
	{
		return lado;
	}
	
	public static void setNumeroLados(int nl)
	{
		numeroLados = nl;
	}
	public static int getNumerosLados()
	{
		return numeroLados;
	}
	
	//metodo construtor
	public Quadrado()
	{
		lado = Float.parseFloat(JOptionPane.showInputDialog("Informe o valor do lado: "));
	}
	
	//operação
	public double calcularArea()
	{	return Math.pow(lado,2);	}
	
	public float calcularPerimetro()
	{	return 4*lado;	}
	
	public double calcularDiagonal()
	{	return Math.sqrt(2*Math.pow(lado,2));	}

	
}
