module Lista6 
{
	requires java.desktop;

	
	
}