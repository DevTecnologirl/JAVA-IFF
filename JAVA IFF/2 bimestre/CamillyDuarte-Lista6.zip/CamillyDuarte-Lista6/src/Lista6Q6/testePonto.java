package Lista6Q6;
import javax.swing.JOptionPane;
public class testePonto 
{
	public static void main(String[] args) 
	{
	//3 passos para teste: 
	//1- criar um objeto da classe: retangulo (instanciar a classe)
	//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
	Ponto objPonto = new Ponto();
	
	//2- chamar as operações do objeto e mostrar os resultados na tela
	
	JOptionPane.showMessageDialog("Distancia da Origem = "+objPonto.calcularDistanciaOrigem();
	}

}
