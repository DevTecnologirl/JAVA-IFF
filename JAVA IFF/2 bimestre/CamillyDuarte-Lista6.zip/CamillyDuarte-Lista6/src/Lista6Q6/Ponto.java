package Lista6Q6;
import javax.swing.JOptionPane;
public class Ponto 
{
	//atributos
		private float x;
		private float y;
		
		//métodos de acesso
		public void setX(float px)
		{	x = px;	}
		
		public float getX()
		{	return x;	}
		
		public void setY(float py)
		{	y = py;	}
		
		public float getY()
		{	return y;	}
		
	//metodo construtor
		public Ponto()
		{
			x = Float.parseFloat(JOptionPane.showInputDialog("Informe o valor de x: "));
			y = Float.parseFloat(JOptionPane.showInputDialog("Informe o valor de y: "));
		}
		
		//operações
		public void moverH(float px)
		{	x = x + px;	}
		
		public void moverV(float py)
		{	y = y + py;	}
		
		public void moverHV(float px,float py)
		{	x = x + px;
			y = y + py;	
		}
		
		public double calcularDistanciaOrigem()
		{	return Math.sqrt(Math.pow(x,2)+Math.pow(y,2));	}
		
		public void informarQuadrante()
		{	if((x>0)&&(y>0))
			{	JOptionPane.showMessageDialog(null,"1º QUADRANTE");	}
			else if((x<0)&&(y>0))
			{	JOptionPane.showMessageDialog(null,"2º QUADRANTE");	}
			else if((x<0)&&(y<0))
			{	JOptionPane.showMessageDialog(null,"3º QUADRANTE");	}
			else if((x>0)&&(y<0))
			{	JOptionPane.showMessageDialog(null,"4º QUADRANTE");	}
			else
			{	JOptionPane.showMessageDialog(null,"ORIGEM");	}	
		}
		
		public void imprimirPonto()
		{	
			JOptionPane.showMessageDialog(null,"P("+x+","+y+")");	
		}
}
