package Lista6Q8;
import javax.swing.JOptionPane;
public class Data 
{
	//atributos
		private int dia;
		private int mes;
		private int ano;
		private String formato;
			
		//métodos de acesso
		public void setDia(int d)
		{	dia = d;	}
			
		public int getDia()
		{	return dia;	}
			
		public void setMes(int m)
		{	mes = m;	}
			
		public int getMes()
		{	return mes;	}
			
		public void setAno(int a)
		{	ano = a;	}
		
		public int getAno()
		{	return ano;	}
			
		public void setFormato(String f)
		{	formato = f;	}
			
		public String getFormato()
		{	return formato;	}
			
		//metodo construtor
		public Data()
		{
			dia = Integer.parseInt(JOptionPane.showInputDialog("Informe o dia: "));
			mes = Integer.parseInt(JOptionPane.showInputDialog("Informe o mes: "));
			ano = Integer.parseInt(JOptionPane.showInputDialog("Infome o ano: "));
			formato = JOptionPane.showInputDialog("Informe o formato: ");
		}
		
		
		//operações
		public void verificarDataValida()
		{	if(ano>=0 && ano<=2021)
			{	if(mes>=1 && mes<=12)
				{	if(mes==1||mes==3||mes==5||mes==7||mes==8||mes==10||mes==12)
					{	if(dia>=1 && dia<=31)
						{	JOptionPane.showMessageDialog(null,"Data válida = "+imprimirData());	}
						else
						{	JOptionPane.showMessageDialog(null,"Dia inválido! Data inválida!");	}			
					}
					else if(mes==4||mes==6||mes==9||mes==11)
					{	if(dia>=1 && dia<=30)
						{	JOptionPane.showMessageDialog(null,"Data válida = "+imprimirData());	}
						else
						{	JOptionPane.showMessageDialog(null,"Dia inválido! Data inválida!");	}			
					}
					else
					{	if(verificarAnoBissexto())
						{	if(dia>=1 && dia<=29)
							{	JOptionPane.showMessageDialog(null,"Data válida = "+imprimirData());	}
							else
							{	JOptionPane.showMessageDialog(null,"Dia inválido! Data inválida!");	}			
						}
						else
						{	if(dia>=1 && dia<=28)
							{	JOptionPane.showMessageDialog(null,"Data válida = "+imprimirData());	}
							else
							{	JOptionPane.showMessageDialog(null,"Dia inválido! Data inválida!");	}			
						}
					}
				}
				else
				{	JOptionPane.showMessageDialog(null,"Mês inválido! Data inválida!");}
			}
			else
			{	JOptionPane.showMessageDialog(null,"Ano inválido! Data inválida!");}	
		}
			
		public boolean verificarAnoBissexto()
		{	if((ano%4==0||ano%400==00)&&(ano%100!=0))
			{	return true;	}
			else
			{	return false;	}
		}
		
		public String imprimirData()
		{	String data,d,m;
			d=String.valueOf(dia);
			m=String.valueOf(mes);
			if(dia<10)
			{	d="0"+d;	}
			if(mes<10)
			{	m="0"+m;	}
			if(formato.equalsIgnoreCase("dd/mm/aaaa"))
			{	data = d+"/"+m+"/"+ano;	}
			else
			{	data = m+"/"+d+"/"+ano;	}
			return data;
		}

}
