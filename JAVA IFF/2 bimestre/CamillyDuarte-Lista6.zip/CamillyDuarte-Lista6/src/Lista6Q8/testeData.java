package Lista6Q8;
import javax.swing.JOptionPane;
public class testeData 
{
	public static void main(String[] args) 
	{
		//3 passos para teste: 
		//1- criar um objeto da classe: retangulo (instanciar a classe)
		//sintaxe: NomeClasse nomeObjeto = new NomeClasse();
		Data objData = new Data();
	
		
		//2- chamar as operações do objeto e mostrar os resultados na tela
		objData.verificarDataValida();
		JOptionPane.showMessageDialog("Ano bissexto = "+objData.verificarAnoBissexto());
		JOptionPane.showMessageDialog("Data imprimida = "+objData.imprimirData());
	}

}
