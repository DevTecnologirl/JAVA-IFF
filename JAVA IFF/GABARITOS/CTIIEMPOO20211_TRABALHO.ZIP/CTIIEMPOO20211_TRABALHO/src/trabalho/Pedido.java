package trabalho;

import javax.swing.JOptionPane;

public class Pedido
{
	//atributos comuns
	private String numeroPedido;
	private float quantidade;
	private String data;
	
	//atributos de refer�ncia que representa o relacionamento
	//entre a classe Pedido e as classes Cliente e Produto.
	private Cliente atRefCliente;
	private Produto atRefProduto;
	private Fatura atRefFatura;	
	
	//m�todos de acesso comuns
	public String getNumeroPedido()
	{	return numeroPedido;	}
	
	public void setNumeroPedido(String numeroPedido)
	{	this.numeroPedido = numeroPedido;	}
	
	public float getQuantidade()
	{	return quantidade;	}
	
	public void setQuantidade(float quantidade)
	{	this.quantidade = quantidade;	}
	
	public String getData()
	{	return data;	}
	
	public void setData(String data)
	{	this.data = data;	}
			
	//m�todos de acesso de refer�ncia
	public Cliente getAtRefCliente()
	{	return atRefCliente;	}

	public void setAtRefCliente(Cliente atRefCliente)
	{	this.atRefCliente = atRefCliente;	}

	public Produto getAtRefProduto()
	{	return atRefProduto;	}

	public void setAtRefProduto(Produto atRefProduto)
	{	this.atRefProduto = atRefProduto;	}

	public Fatura getAtRefFatura()
	{	return atRefFatura;	}

	public void setAtRefFatura(Fatura atRefFatura)
	{	this.atRefFatura = atRefFatura;	}	
	
	//m�todo construtor
	public Pedido()
	{	numeroPedido = JOptionPane.showInputDialog("Informe o n�mero do pedido:");
		quantidade = Float.parseFloat(JOptionPane.showInputDialog("Informe a quantidade do pedido:"));
		data = JOptionPane.showInputDialog("Informe a data do pedido:");
	}

	//opera��es
	public void gerarFatura()
	{	Fatura objFatura = new Fatura();
		objFatura.setValorTotal(quantidade*atRefProduto.getPrecoUnitario());
		atRefFatura = objFatura;
	}
}