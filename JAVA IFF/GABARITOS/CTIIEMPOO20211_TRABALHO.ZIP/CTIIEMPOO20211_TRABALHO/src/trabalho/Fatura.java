package trabalho;

import javax.swing.JOptionPane;

public class Fatura
{
	//atributos comuns
	private String numeroFatura;
	private String dataVencimento;
	private float valorTotal;
	
	//m�todos de acesso comuns
	public String getNumeroFatura() {
		return numeroFatura;
	}
	public void setNumeroFatura(String numeroFatura) {
		this.numeroFatura = numeroFatura;
	}
	public String getDataVencimento() {
		return dataVencimento;
	}
	public void setDataVencimento(String dataVencimento) {
		this.dataVencimento = dataVencimento;
	}
	public float getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(float valorTotal) {
		this.valorTotal = valorTotal;
	}
			
	//m�todo construtor
	public Fatura()
	{	numeroFatura = JOptionPane.showInputDialog("Informe o n�mero da fatura:");
		dataVencimento = JOptionPane.showInputDialog("Informe a data de vencimento da fatura:");
	}	
}