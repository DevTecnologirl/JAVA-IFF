package trabalho;

import javax.swing.JOptionPane;

public class Produto
{
	//atributos comuns
	private String codigo;
	private String nome;
	private float quantidade;
	private float precoUnitario;
	
	//m�todos de acesso comuns
	public String getCodigo()
	{	return codigo;	}
	
	public void setCodigo(String codigo)
	{	this.codigo = codigo;	}
	
	public String getNome()
	{	return nome;	}
	
	public void setNome(String nome)
	{	this.nome = nome;	}
	
	public float getQuantidade()
	{	return quantidade;	}
	
	public void setQuantidade(float quantidade)
	{	this.quantidade = quantidade;	}
	
	public float getPrecoUnitario()
	{	return precoUnitario;	}
	
	public void setPrecoUnitario(float precoUnitario)
	{	this.precoUnitario = precoUnitario;	}
	
	public Produto()
	{	codigo = JOptionPane.showInputDialog("Informe o c�digo do produto:");
		nome = JOptionPane.showInputDialog("Informe o nome do produto:");
		quantidade = Float.parseFloat(JOptionPane.showInputDialog("Informe a quantidade do produto:"));
		precoUnitario = Float.parseFloat(JOptionPane.showInputDialog("Informe o pre�o unit�rio do produto:"));
	}
}