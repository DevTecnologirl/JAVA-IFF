package trabalho;

import javax.swing.JOptionPane;

public class Compra
{
	public static void main(String[] args)
	{	
		String resposta = JOptionPane.showInputDialog("Pessoa F�sica ou Pessoa Jur�dica?");
		
		if(resposta.equalsIgnoreCase("Pessoa F�sica"))
		{	PessoaFisica objPF = new PessoaFisica();	}
		else
		{	PessoaJuridica objPJ = new PessoaJuridica();	}
	}
}