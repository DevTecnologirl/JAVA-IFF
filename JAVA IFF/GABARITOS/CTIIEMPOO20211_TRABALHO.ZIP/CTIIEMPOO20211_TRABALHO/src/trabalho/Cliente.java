package trabalho;

import javax.swing.JOptionPane;

public abstract class Cliente
{
	//atributo comum
	protected String nome;
	
	//atributos de refer�ncia que representam o relacionamento entre
	//a classe Cliente e as classes Endere�o, Telefone, Produto e Pedido.
	protected Endereco atRefEndereco;
	protected Telefone atRefTelefone;
	protected Produto atRefProduto;
	protected Pedido atRefPedido;
	
	//m�todos de acesso comuns
	public String getNome()
	{	return nome;	}

	public void setNome(String nome)
	{	this.nome = nome;	}
		
	//m�todos de acesso de refer�ncia
	public Endereco getAtRefEndereco()
	{	return atRefEndereco;	}

	public void setAtRefEndereco(Endereco atRefEndereco)
	{	this.atRefEndereco = atRefEndereco;	}

	public Telefone getAtRefTelefone()
	{	return atRefTelefone;	}

	public void setAtRefTelefone(Telefone atRefTelefone)
	{	this.atRefTelefone = atRefTelefone;	}

	public Produto getAtRefProduto()
	{	return atRefProduto;	}

	public void setAtRefProduto(Produto atRefProduto)
	{	this.atRefProduto = atRefProduto;	}

	public Pedido getAtRefPedido()
	{	return atRefPedido;	}

	public void setAtRefPedido(Pedido atRefPedido)
	{	this.atRefPedido = atRefPedido;	}

	//m�todo construtor
	public Cliente()
	{	nome = JOptionPane.showInputDialog("Informe o nome do cliente: ");
		Endereco objE = new Endereco();
		Telefone objT = new Telefone();
		atRefEndereco = objE;
		atRefTelefone = objT;				
	}
	
	//opera��es
	public void fazerPedido()
	{	Pedido objPedido = new Pedido();
		Produto objProduto = new Produto();
		atRefPedido = objPedido;
		atRefProduto = objProduto;
		atRefPedido.setAtRefProduto(objProduto);
		atRefPedido.gerarFatura();
	}
	
	public void imprimirFatura()
	{
		JOptionPane.showMessageDialog(null,"DADOS DO CLIENTE:"
				+ "\nNome: "+nome
				+"\n\nENDERE�O COMPLETO: "
				+"Rua "+atRefEndereco.getRua()
				+", "+atRefEndereco.getNumero()
				+" - "+atRefEndereco.getComplemento()
				+" - "+atRefEndereco.getBairro()
				+" - "+atRefEndereco.getCidade()
				+"/"+atRefEndereco.getEstado()
				+" - CEP: "+atRefEndereco.getCep()
				+"\n\nTELEFONE COMPLETO: "
				+"+"+atRefTelefone.getDdi()
				+" ("+atRefTelefone.getDdd()
				+") "+atRefTelefone.getNumero()
				+" - "+atRefTelefone.getTipo()
				+" - "+atRefTelefone.getOperadora()
				+"\n\nDADOS DO PEDIDO:"				
				+"\nN�mero do pedido: "+atRefPedido.getNumeroPedido()
				+"\nQuantidade do pedido: "+atRefPedido.getQuantidade()
				+"\nData do pedido: "+atRefPedido.getData()
				+"\n\nDADOS DO PRODUTO: "
				+"\nC�digo do produto: "+atRefProduto.getCodigo()
				+"\nNOme do produto: "+atRefProduto.getNome()
				+"\nQuantidade do produto: "+atRefProduto.getQuantidade()
				+"\nPre�o unit�rio do produto: "+atRefProduto.getPrecoUnitario()
				+"\n\nDADOS DA FATURA: "
				+"\nN�mero da fatura: "+atRefPedido.getAtRefFatura().getNumeroFatura()
				+"\nData de vencimento da fatura: "+atRefPedido.getAtRefFatura().getDataVencimento()
				+"\nValor total da fatura: "+atRefPedido.getAtRefFatura().getValorTotal());
	}
}