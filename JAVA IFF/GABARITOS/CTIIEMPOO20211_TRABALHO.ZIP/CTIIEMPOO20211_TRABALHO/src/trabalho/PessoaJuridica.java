package trabalho;

import javax.swing.JOptionPane;

public class PessoaJuridica extends Cliente
{
	//atributo comum
	private String cnpj;

	//m�todos de acesso comuns
	public String getCnpj()
	{	return cnpj;	}

	public void setCnpj(String cnpj)
	{	this.cnpj = cnpj;	}		
	
	//m�todo construtor
	public PessoaJuridica()
	{	super();
		cnpj = JOptionPane.showInputDialog("Informe o CNPJ do cliente (pessoa jur�dica):");
		fazerPedido();
		imprimirFatura();
	}
	
}