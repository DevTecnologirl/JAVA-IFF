package trabalho;

import javax.swing.JOptionPane;

public class PessoaFisica extends Cliente
{
	//atributos comuns
	private String cpf;
	private String dtNascimento;

	//m�todos de acesso comuns
	public String getCpf()
	{	return cpf;	}
	
	public void setCpf(String cpf)
	{	this.cpf = cpf;	}
	
	public String getDtNascimento()
	{	return dtNascimento;	}
	
	public void setDtNascimento(String dtNascimento)
	{	this.dtNascimento = dtNascimento;	}
			
	//m�todo construtor
	public PessoaFisica()
	{	super();
		cpf = JOptionPane.showInputDialog("Informe o CPF do cliente (pessoa f�sica):");
		dtNascimento = JOptionPane.showInputDialog("Informe a data de nascimento (pessoa f�sica):");
		fazerPedido();
		imprimirFatura();
	}
}