package lista03questao08;

public class Data
{
	//atributos
	private int dia;
	private int mes;
	private int ano;
	private String formato;
		
	//opera��es
	public void verificarDataValida()
	{	if(ano>=0 && ano<=2021)
		{	if(mes>=1 && mes<=12)
			{	if(mes==1||mes==3||mes==5||mes==7||mes==8||mes==10||mes==12)
				{	if(dia>=1 && dia<=31)
					{	System.out.println("Data v�lida = "+imprimirData());	}
					else
					{	System.out.println("Dia inv�lido! Data inv�lida!");	}			
				}
				else if(mes==4||mes==6||mes==9||mes==11)
				{	if(dia>=1 && dia<=30)
					{	System.out.println("Data v�lida = "+imprimirData());	}
					else
					{	System.out.println("Dia inv�lido! Data inv�lida!");	}			
				}
				else
				{	if(verificarAnoBissexto())
					{	if(dia>=1 && dia<=29)
						{	System.out.println("Data v�lida = "+imprimirData());	}
						else
						{	System.out.println("Dia inv�lido! Data inv�lida!");	}			
					}
					else
					{	if(dia>=1 && dia<=28)
						{	System.out.println("Data v�lida = "+imprimirData());	}
						else
						{	System.out.println("Dia inv�lido! Data inv�lida!");	}			
					}
				}
			}
			else
			{	System.out.println("M�s inv�lido! Data inv�lida!");}
		}
		else
		{	System.out.println("Ano inv�lido! Data inv�lida!");}	
	}
		
	public boolean verificarAnoBissexto()
	{	if((ano%4==0||ano%400==00)&&(ano%100!=0))
		{	return true;	}
		else
		{	return false;	}
	}
	
	public String imprimirData()
	{	String data,d,m;
		d=String.valueOf(dia);
		m=String.valueOf(mes);
		if(dia<10)
		{	d="0"+d;	}
		if(mes<10)
		{	m="0"+m;	}
		if(formato.equalsIgnoreCase("dd/mm/aaaa"))
		{	data = d+"/"+m+"/"+ano;	}
		else
		{	data = m+"/"+dia+"/"+ano;	}
		return data;
	}
}