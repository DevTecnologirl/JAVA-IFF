package lista03questao01;

public class Retangulo
{
	//atributos
	private float base;
	private float altura;

	//opera��es
	public float calcularArea()
	{	return base*altura;	}
	
	public float calcularPerimetro()
	{	return 2*(base+altura);	}

	public double calcularDiagonal()
	{	return Math.sqrt(Math.pow(base,2) + Math.pow(altura,2));	}
}