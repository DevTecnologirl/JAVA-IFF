package lista03questao04;

public class Triangulo
{
	//atributos
	private float base;
	private float altura;
	private String tipo;
	
	//opera��es
	public float calcularArea()
	{	return (base*altura)/2;		}
	
	public double calcularPerimetro()
	{	if(tipo.equalsIgnoreCase("equil�tero"))
		{	return 3*base;	}
		else if(tipo.equalsIgnoreCase("is�seles"))
		{	return (2* Math.sqrt(Math.pow(altura,2)+Math.pow(base/2,2)))+base;	}
		else
		{	float lado1=10,lado2=20;	
			return lado1+lado2+base;	
		}	
	}
}