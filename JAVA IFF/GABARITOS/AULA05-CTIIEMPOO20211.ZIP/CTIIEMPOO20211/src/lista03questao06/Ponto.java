package lista03questao06;

public class Ponto
{
	//atributos
	private float x;
	private float y;
	
	//opera��es
	public void moverH(float px)
	{	x = x + px;	}
	
	public void moverV(float py)
	{	y = y + py;	}
	
	public void moverHV(float px,float py)
	{	x = x + px;
		y = y + py;	
	}
	
	public double calcularDistanciaOrigem()
	{	return Math.sqrt(Math.pow(x,2)+Math.pow(y,2));	}
	
	public void informarQuadrante()
	{	if((x>0)&&(y>0))
		{	System.out.println("1� QUADRANTE");	}
		else if((x<0)&&(y>0))
		{	System.out.println("2� QUADRANTE");	}
		else if((x<0)&&(y<0))
		{	System.out.println("3� QUADRANTE");	}
		else if((x>0)&&(y<0))
		{	System.out.println("4� QUADRANTE");	}
		else
		{	System.out.println("ORIGEM");	}	
	}
	
	public void imprimirPonto()
	{	System.out.println("P("+x+","+y+")");	}
}