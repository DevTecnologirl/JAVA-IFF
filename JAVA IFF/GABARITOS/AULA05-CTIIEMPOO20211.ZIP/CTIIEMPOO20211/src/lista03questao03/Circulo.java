package lista03questao03;

public class Circulo
{
	//atributo
	private float raio;
	
	//opera��es
	public double calcularArea()
	{	return Math.PI*Math.pow(raio,2);	}
	
	public double calcularPerimetro()
	{	return 2*Math.PI*raio;	}
	
	public float calcularDiametro()
	{	return 2*raio;	}
}