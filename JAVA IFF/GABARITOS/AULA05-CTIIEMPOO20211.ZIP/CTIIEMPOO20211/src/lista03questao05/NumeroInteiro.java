package lista03questao05;

public class NumeroInteiro
{
	//atributo
	private int valor;
	
	//opera��es
	public double calcularRaiz2()
	{	return Math.sqrt(valor);	}
	
	public double calcularRaiz3()
	{	return Math.cbrt(valor);	}
	
	public double calcularPotencia(float exp)
	{	return Math.pow(valor,exp);	}
	
	public int calcularFatorial()
	{	int fat=1;
		if(valor>1)
		{	for(int i=1;i<=valor;i++)
			{ fat = fat*i;	}
		}
		return fat;
	}
	
	public void verificarParouImpar()
	{	if(valor%2==0)
		{	System.out.println("O n�mero � par!");		}
		else
		{	System.out.println("O n�mero � �mpar!");	}
	}
	
	public boolean verificarPrimo()
	{	int cont=0;
		for(int i=1;i<=valor;i++)
		{	if(valor%i==0)
			{	cont++;	}
		}
		if(cont==2)
		{	return true;	}
		else
		{	return false;	}
	}
}