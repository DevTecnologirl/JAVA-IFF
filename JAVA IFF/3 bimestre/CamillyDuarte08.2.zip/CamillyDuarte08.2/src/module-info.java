module lista08 {
	requires java.desktop;
}