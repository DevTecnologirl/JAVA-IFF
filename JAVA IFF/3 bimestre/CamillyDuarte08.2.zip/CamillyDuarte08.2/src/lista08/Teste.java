package lista08;

public class Teste 
{
public static void main(String[] args) 
{
	
	TelaPrincipal objPrincipal = new TelaPrincipal();
	objPrincipal.show();
}
}

