package testeJFrame;

public class TesteJanela
{	
	public static void main(String[] args)
	{	Janela objTela = new Janela();
		objTela.repaint();
		objTela.show();
	}
}