package testeJFrame;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class JanelaGridLayout extends JFrame
{
	//m�todo construtor
		public JanelaGridLayout()
		{	this.setTitle("Tela de Simula��o do Gerenciador GridLayout");
			this.setSize(500,300);
			this.setVisible(true);
			this.setResizable(false);
				
			//2� passo: capturar a �rea �til da janela
			Container c = this.getContentPane();
			
			//3� passo: criar um gerenciador de layout e aplic�-lo ao container geral da janela			
			GridLayout layout = new GridLayout(2,2,5,5);
			c.setLayout(layout);

		   JButton botao1 = new JButton("One");
		   JButton botao2 = new JButton("Two");
		   JButton botao3 = new JButton("Three");
		   JButton botao4 = new JButton("Four");
		   
		   c.add (botao1);
		   c.add (botao2);
		   c.add (botao3);
		   c.add (botao4);
		}		
}