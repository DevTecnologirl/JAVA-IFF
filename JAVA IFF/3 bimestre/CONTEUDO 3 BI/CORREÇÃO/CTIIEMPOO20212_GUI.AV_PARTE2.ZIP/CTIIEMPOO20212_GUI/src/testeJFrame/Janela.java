package testeJFrame;

import javax.swing.JFrame;
import java.awt.Container;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.Font;
import java.awt.Color;

//1� passo: criar uma janela herdando de JFrame
public class Janela extends JFrame
{	

	//m�todo construtor
	public Janela()
	{	this.setTitle("Tela de Acesso ao Sistema");
		this.setSize(500,300);
		this.setVisible(true);
		this.setResizable(false);
		
		//2� passo: capturar a �rea �til da janela
		Container c = this.getContentPane();
		
		//3� passo: criar um painel e adicion�-lo ao container geral da janela
		JPanel painel = new JPanel();
		c.add(painel);
		
		//4� passo: criar r�tulo e adicion�-lo ao painel 
		JLabel rotulo1 = new JLabel("Informe o nome do usu�rio: ");
		rotulo1.setToolTipText("username");
		painel.add(rotulo1);

		//5� passo: criar uma caixa de texto e adicion�-la ao painel
		JTextField caixa1 = new JTextField(25);
		painel.add(caixa1);
		
		//6� passo: criar mais um r�tulo e adicion�-lo ao painel
		JLabel rotulo2 = new JLabel("Informe a senha de acesso: ");
		rotulo2.setToolTipText("password");
		painel.add(rotulo2);
		
		//7� passo: criar uma caixa de texto para senha e adicion�-la ao painel
		JPasswordField senha = new JPasswordField(25);
		painel.add(senha);
		
		//8� passo: criar r�tulo e checkboxs/radiobuttons/combobox/list e adicion�-los ao painel
		JLabel rotulo3 = new JLabel("� obrigat�rio selecionar o(s) perfil(is) desejado(s) para acesso aos sistemas: ");
		rotulo3.setToolTipText("perfil de acesso");
		painel.add(rotulo3);
		
		/*
		JCheckBox escolha1 = new JCheckBox("Administrador",false); 
		JCheckBox escolha2 = new JCheckBox("Programador",false);
		JCheckBox escolha3 = new JCheckBox("DBA",false);
		JCheckBox escolha4 = new JCheckBox("Usu�rio",true);
		JCheckBox escolha5 = new JCheckBox("Testador",false);

		painel.add(escolha1);
		painel.add(escolha2);
		painel.add(escolha3);
		painel.add(escolha4);
		painel.add(escolha5);
				
		JRadioButton radio1 = new JRadioButton("Administrador",false);
		JRadioButton radio2 = new JRadioButton("Programador",false);
		JRadioButton radio3 = new JRadioButton("DBA",false);
		JRadioButton radio4 = new JRadioButton("Usu�rio Final",true);
		JRadioButton radio5 = new JRadioButton("Testador",false);		
		
		ButtonGroup grupo = new ButtonGroup();
		grupo.add(radio1);
		grupo.add(radio2);
		grupo.add(radio3);
		grupo.add(radio4);
		grupo.add(radio5);
		
		painel.add(radio1);
		painel.add(radio2);
		painel.add(radio3);
		painel.add(radio4);
		painel.add(radio5);
		
		String[] perfil = {"Administrador","Programador","DBA","Usu�rio Final","Testador"};
		JComboBox combo = new JComboBox(perfil);
		combo.setMaximumRowCount(4);
		painel.add(combo);
		*/

		String[] list = {"Administrador", "Programador", "DBA", "Usu�rio Final","Testador"};
		JList lista = new JList (list);
		//lista.setVisibleRowCount(4);
		lista.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		painel.add(lista);

		
		//9� passo: criar bot�es e adicion�-los ao painel
		JButton botao1 = new JButton("Entrar");
		JButton botao2 = new JButton("Limpar");
		JButton botao3 = new JButton("Fechar");
		
		Font letra = new Font("SansSerif",Font.BOLD,24);
		botao1.setFont(letra);
		botao1.setBackground(new Color(117,76,128));
	  	botao1.setForeground(Color.yellow);
		
		painel.add(botao1);
		painel.add(botao2);
		painel.add(botao3);

		//adicionando eventos aos bot�es criados
		botao1.addActionListener(new ActionListener()
		{	public void actionPerformed(ActionEvent e)
			{	JOptionPane.showMessageDialog(null,"USU�RIO: " +
	 				caixa1.getText() + "\nSENHA: " +senha.getText());
		}});
	
		botao2.addActionListener(new ActionListener()
		{	public void actionPerformed(ActionEvent e)
			{	caixa1.setText("");
					senha.setText("");
		}});
	
		botao3.addActionListener(new ActionListener()
		{	public void actionPerformed(ActionEvent e)
			{	System.exit(0);	
		}});
		
		
		//10� passo: criar uma barra de menus e adicion�-la � janela
		JMenuBar barraMenus = new JMenuBar();
		this.setJMenuBar(barraMenus);
		
		//11� passo: criar v�rios menus e adicion�-los � barra de menus criada anteriormente
		JMenu menu1 = new JMenu("Cadastros B�sicos");
		JMenu menu2 = new JMenu("Consultas");
		JMenu menu3 = new JMenu("Relat�rios");
		JMenu menu4 = new JMenu("Ajuda");

		barraMenus.add(menu1);
		barraMenus.add(menu2);
		barraMenus.add(menu3);
		barraMenus.add(menu4);

		//12� passo: criar v�rios itens de menu e adicion�-los aos menus criados anteriormente
		JMenuItem item1 = new JMenuItem("Usu�rios");
		JMenuItem item2 = new JMenuItem("Recuperar Senha");
		JMenuItem item31 = new JMenuItem("Usu�rios Cadastrados");
		JMenuItem item32 = new JMenuItem("Lista de Emails");
		JMenuItem item4 = new JMenuItem("Sobre");

		menu1.add(item1);
	 	menu2.add(item2);
		menu3.add(item31);
		menu3.add(item32);
		menu4.add(item4);

		//13� passo: criar v�rios eventos e associ�-los aos itens de menu criados anteriormente
		item1.addActionListener(new ActionListener()
		 {	public void actionPerformed(ActionEvent e)
				{	JOptionPane.showMessageDialog(null,"ACIONOU O ITEM DE MENU 1!");
			 		//TelaLivro objTLivro = new TelaLivro();
		 }});

		 item2.addActionListener(new ActionListener()
		 {	public void actionPerformed(ActionEvent e)
				{	JOptionPane.showMessageDialog(null,"ACIONOU O ITEM DE MENU 2!");
		 }});

		 item31.addActionListener(new ActionListener()
		 {	public void actionPerformed(ActionEvent e)
				{	JOptionPane.showMessageDialog(null,"ACIONOU O ITEM DE MENU 3.1!");
		 }});
		
		 item32.addActionListener(new ActionListener()
		 {	public void actionPerformed(ActionEvent e)
				{	JOptionPane.showMessageDialog(null,"ACIONOU O ITEM DE MENU 3.2!");
		 }});
		 
		 item4.addActionListener(new ActionListener()
		 {	public void actionPerformed(ActionEvent e)
				{	JOptionPane.showMessageDialog(null,"ACIONOU O ITEM DE MENU 4!");
		 }});

	}
}