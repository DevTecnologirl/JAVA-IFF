package testeJFrame;

public class TesteJanela
{	
	public static void main(String[] args)
	{	
		/*Janela objTela = new Janela();
		objTela.repaint();
		objTela.show();
		*/

		/*JanelaFlowLayout objTela = new JanelaFlowLayout();
		objTela.repaint();
		objTela.show();
		*/
		
		/*JanelaBorderLayout objTela = new JanelaBorderLayout();
		objTela.repaint();
		objTela.show();
		*/
		
		JanelaGridLayout objTela = new JanelaGridLayout();
		objTela.repaint();
		objTela.show();

	}
}