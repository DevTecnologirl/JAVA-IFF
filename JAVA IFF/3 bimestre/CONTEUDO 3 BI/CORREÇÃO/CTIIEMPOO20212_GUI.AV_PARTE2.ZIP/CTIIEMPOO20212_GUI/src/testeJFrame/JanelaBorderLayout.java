package testeJFrame;

import javax.swing.JFrame;
import java.awt.Container;
import java.awt.BorderLayout;
import javax.swing.JButton;

public class JanelaBorderLayout extends JFrame
{

	//m�todo construtor
	public JanelaBorderLayout()
	{	this.setTitle("Tela de Simula��o do Gerenciador BorderLayout");
		this.setSize(500,300);
		this.setVisible(true);
		this.setResizable(false);
			
		//2� passo: capturar a �rea �til da janela
		Container c = this.getContentPane();
		
		//3� passo: criar um gerenciador de layout e aplic�-lo ao container geral da janela			
		BorderLayout layout = new BorderLayout(5,5);
		c.setLayout(layout);

	   JButton botao1 = new JButton("Topo");
	   JButton botao2 = new JButton("Rodap�");
	   JButton botao3 = new JButton("Esquerda");
	   JButton botao4 = new JButton("Centro");
	   JButton botao5 = new JButton("Direita");
	   
	   c.add (botao1,BorderLayout.NORTH);
	   c.add (botao2,BorderLayout.SOUTH);
	   c.add (botao3,BorderLayout.WEST);
	   c.add (botao4,BorderLayout.CENTER);
	   c.add (botao5,BorderLayout.EAST);		
	}	
}