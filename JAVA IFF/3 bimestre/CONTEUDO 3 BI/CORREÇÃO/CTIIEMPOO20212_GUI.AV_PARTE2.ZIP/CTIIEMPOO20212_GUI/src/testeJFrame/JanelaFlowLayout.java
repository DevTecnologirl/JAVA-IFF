package testeJFrame;

import java.awt.Container;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class JanelaFlowLayout extends JFrame
{

	//m�todo construtor
	public JanelaFlowLayout()
	{	this.setTitle("Tela de Simula��o do Gerenciador FlowLayout");
		this.setSize(50,300);
		this.setVisible(true);
		this.setResizable(false);
		
		//2� passo: capturar a �rea �til da janela
		Container c = this.getContentPane();
		
		//3� passo: criar um gerenciador de layout e aplic�-lo ao container geral da janela	
		FlowLayout layout = new FlowLayout();
		c.setLayout(layout);
		layout.setAlignment(FlowLayout.RIGHT);

		JButton botao1 = new JButton("Entrar");
		JButton botao2 = new JButton("Limpar");
		JButton botao3 = new JButton("Fechar");
		
		c.add(botao1);
		c.add(botao2);
		c.add(botao3);
		
	}	
}