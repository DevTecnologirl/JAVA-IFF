package apresentacao;

import apresentacao.TelaProduto;

public class Teste
	{	
	public static void main(String[] args) 
	{
		
		TelaProduto objProduto = new TelaProduto();
		objProduto.show();
	}
	}


