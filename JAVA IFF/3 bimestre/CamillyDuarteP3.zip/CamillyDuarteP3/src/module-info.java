module CamillyDuarteP3
{
	requires java.desktop;
	//ESBOÇO DE ORDEM NA PROVA
	
	/*                                       
	 * //atributos
	private int codigo;
	private String nome;
	private int quantidade;
	private float preco;
	private Object JOptionPane;
	
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
	public float getPreco() {
		return preco;
	}
	public void setPreco(float preco) {
		this.preco = preco;
	}
	

	
		
		public Produto(int cd,String nm,int qt,float pr)
		{	codigo = cd;
			nome = nm;
			quantidade = qt;
			preco = pr;
			
		}
		public Produto() {
			codigo = JOptionPane.showInputDialog("Informe o codigo: ");
			nome = Integer.parseInt(JOptionPane.showInputDialog("Informe o nome: "));
			 quantidade = JOptionPane.showInputDialog("Informe a quantidade: ");
			 preco= JOptionPane.showInputDialog("Informe o preco: ");
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	
	
	/* TELA PRINCIPAL--------------------
	 * 
	 * ATRIBUTO COMUNS
	 * 
	 * MUDAR O ÍCONE DA TELA PRINCIPAL
	 * 
	 * COLOCAR IMAGEM DE FUNDO
	 * 
	 * CAPTURA DE AREA UTIL NA TELA (CONTRAINER)
	 * 
	 * DEFINIÇÃO DO GERENCIADOR DE LAYOUT
	 * 
	 * CRIACAO DE BARRA DE STATUS
	 * 
	 * CRIACAO DE BARRAS DE MENU - MENU E INTENS
	 * 
	 * CRIACAO DE MENUS
	 * 
	 * CRIACAO DE ITENS
	 * 
	 * ADD EVENTOS AOS ITENS DE MENU
	 * 
	 * ADD ITENS DE MENU EM CADA MENU
	 * 
	 * ADD MENUS BARRA DE MENUS
	 * 
	 * ADD BARRA DE MENUS JANELA
	 * 
	 * 
	 */
}